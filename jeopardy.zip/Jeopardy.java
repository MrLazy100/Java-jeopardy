package jeopardy;
import java.io.*;
import java.util.*;

public class Jeopardy 
{
    public static void main(String[] args) 
    {
        
    }
    
}
